# Imports here
#%matplotlib inline
#%config InlineBackend.figure_format = 'retina'
import matplotlib.pyplot as plt
import numpy as np
import torch
from torch import nn
from torchvision import datasets, transforms, models
from torch import optim
import torch.nn.functional as F
from PIL import Image
from torch.autograd import Variable
import argparse
import seaborn as sns
import json
from collections import OrderedDict


data_dir = 'flowers'
train_dir = data_dir + '/train'
valid_dir = data_dir + '/valid'
test_dir = data_dir + '/test'



# TODO: Define your transforms for the training, validation, and testing sets
data_transforms_train = transforms.Compose([transforms.RandomResizedCrop(224),
                                              transforms.RandomRotation(30),
                                              transforms.RandomHorizontalFlip(),
                                              transforms.ToTensor(),
                                              transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])

data_transforms_valid = transforms.Compose([transforms.RandomResizedCrop(224),
                                            transforms.ToTensor(),
                                           transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])

data_transforms_test = transforms.Compose([transforms.RandomResizedCrop(224),
                                           transforms.ToTensor(),
                                          transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])

# TODO: Load the datasets with ImageFolder
image_datasets_train = datasets.ImageFolder(data_dir + '/train', transform = data_transforms_train)
image_datasets_valid = datasets.ImageFolder(data_dir + '/valid', transform = data_transforms_valid)
image_datasets_test = datasets.ImageFolder(data_dir + '/test', transform = data_transforms_test)

# TODO: Using the image datasets and the trainforms, define the dataloaders
dataloaders_train =  torch.utils.data.DataLoader(image_datasets_train , batch_size = 32, shuffle = True)
dataloaders_valid =  torch.utils.data.DataLoader(image_datasets_valid , batch_size = 32, shuffle = True)
dataloaders_test =  torch.utils.data.DataLoader(image_datasets_test , batch_size = 32, shuffle = True)



with open('cat_to_name.json', 'r') as f:
    cat_to_name = json.load(f)   
    
    
# TODO: Build and train your network
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

model = models.vgg16(pretrained = True)
    
for param in model.parameters():
    param.requires_grad = False
    
model.classifier = nn.Sequential(OrderedDict([('fc1', nn.Linear(25088, 512)),
                                ('relu', nn.ReLU()),
                                ('drop', nn.Dropout(p = 0.2)),
                                ('fc2', nn.Linear(512, 102)),
                                
                                ('output', nn.LogSoftmax(dim = 1))]))
criterion = nn.NLLLoss()
optimizer = optim.Adam(model.classifier.parameters(), lr = 0.001)

model.to(device);

# Training Network(model) with the training dataset
if __name__ == '__main__':
    paser = argparse.ArgumentParser(description='training image classifier')

    paser.add_argument('data_dir', type=str, default='flowers', help='dataset directory')
    paser.add_argument('--gpu', type=bool, default='True', help='True: gpu, False: cpu')
    paser.add_argument('--epochs', type=int, default=10, help='number of epochs')
    paser.add_argument('--lr', type=float, default=0.001, help='learning rate')
    paser.add_argument('--arch', type=str, default='vgg16', help='architecture')
    paser.add_argument('--hidden_units', type=int, default=512, help='hidden units for layer')
    paser.add_argument('--checkpoint', type=str, default='checkpoint.pth', help='save trained model to a file')
    
    args = paser.parse_args()
    

#for i in keep_awake(range(1)):

    epochs = 10
    running_loss = 0
    print_every = 100
    steps = 0

    train_losses, valid_losses = [], []

    for epoch in range(epochs):   
        for images, labels in dataloaders_train:
            steps += 1

            images, labels = images.to(device), labels.to(device)

            optimizer.zero_grad()
            #images.view(images.shape[0], 3, -1 )

            logps = model.forward(images)
            train_loss = criterion(logps, labels)
            train_loss.backward()
            optimizer.step()

            running_loss += train_loss.item()

            if steps % print_every == 0:
                model.eval()
                valid_loss = 0
                accuracy = 0
                
                # turning the gradient off for the validation stage for faster computation
                with torch.no_grad():
                    for images, labels in dataloaders_valid:
                        images, labels = images.to(device), labels.to(device)
                        logps = model(images)
                        loss = criterion(logps, labels)
                        valid_loss += loss.item()

                        ps = torch.exp(logps)
                        top_p, top_class = ps.topk(1, dim=1)
                        equals = top_class == labels.view(*top_class.shape)
                        accuracy += torch.mean(equals.type(torch.FloatTensor)).item()

                        train_losses.append(running_loss/len(dataloaders_train))
                        valid_losses.append(valid_loss/len(dataloaders_valid))  


                print(f"Epoch {epoch+1}/{epochs}.. "
                          f"Train loss: {running_loss/len(dataloaders_train):.3f}.. "
                          f"Valid loss: {valid_loss/len(dataloaders_valid):.3f}.. "
                          f"Accuracy: {accuracy/len(dataloaders_valid):.3f}")
                running_loss = 0
                model.train()       


# testing network
def test_network(dataloaders_test):
    
    test_loss = 0
    accuracy = 0
    model.eval()
    with torch.no_grad():
        for images, labels in dataloaders_test:
            images, labels = images.to(device), labels.to(device)
            logps = model(images)
            test_loss += criterion(logps, labels)

            ps = torch.exp(logps)
            top_p, top_class = ps.topk(1, dim=1)
            equals = top_class == labels.view(*top_class.shape)
            accuracy += torch.mean(equals.type(torch.FloatTensor))
        print(f"Test accuracy: {accuracy/len(dataloaders_test):.3f}")
            
test_network(dataloaders_test)
    



# mapping classes to indices
model.class_to_idx = image_datasets_train.class_to_idx
model.cpu()

# saving model
torch.save({'arch': args.arch,
            'model' :models.vgg16(pretrained=True),
            'classifier': model.classifier,
            'state_dict': model.state_dict(),
            'class_to_idx' : model.class_to_idx,
            'epochs' : args.epochs, 
            'optimizer_state_dict' : optimizer.state_dict(), 
            'lr' : args.lr},   
            args.checkpoint)

#torch.save(model, 'checkpoint.pth')